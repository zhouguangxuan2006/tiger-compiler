#include "tiger/frame/x64frame.h"
#include <array>

extern frame::RegManager *reg_manager;

namespace frame {

X64RegManager::X64RegManager() : RegManager() {
  for (int i = 0; i < REG_COUNT; i++)
    RegManager::regs_.push_back(temp::TempFactory::NewTemp());

  const char* reg_name[REG_COUNT] = {
      "%rax", "%rcx", "%rdx", "%rsi", "%rdi", "%r8",  "%r9",  "%rbx",
      "%rbp", "%r10", "%r11", "%r12", "%r13", "%r14", "%r15", "%rsp",
  };
  for (int i = 0; i < REG_COUNT; i++) {
    RegManager::temp_map_->Enter(RegManager::regs_[i], new std::string(reg_name[i]));
  }
}

temp::TempList *X64RegManager::Registers() {
  const std::array<int, 15> reg_array{
      REG_RAX, REG_RBX, REG_RCX, REG_RDX, REG_RSI, REG_RDI, REG_RBP,
      REG_R8,  REG_R9,  REG_R10, REG_R11, REG_R12, REG_R13, REG_R14, REG_R15,
  };
  auto *temp_list = new temp::TempList();
  for (auto reg : reg_array)
    temp_list->Append(RegManager::regs_[reg]);
  return temp_list;
}

temp::TempList *X64RegManager::ArgRegs() {
  const std::array<int, 6> reg_array{REG_RDI, REG_RSI, REG_RDX, REG_RCX, REG_R8, REG_R9};
  auto *temp_list = new temp::TempList();
  for (auto reg : reg_array)
    temp_list->Append(RegManager::regs_[reg]);
  return temp_list;
}

temp::TempList *X64RegManager::CallerSaves() {
  const std::array<int, 9> reg_array{REG_RAX, REG_RDI, REG_RSI, REG_RDX, REG_RCX, REG_R8, REG_R9, REG_R10, REG_R11};
  auto *temp_list = new temp::TempList();
  for (auto reg : reg_array)
    temp_list->Append(RegManager::regs_[reg]);
  return temp_list;
}

temp::TempList *X64RegManager::CalleeSaves() {
  const std::array<int, 6> reg_array{REG_RBP, REG_RBX, REG_R12, REG_R13, REG_R14, REG_R15};
  auto *temp_list = new temp::TempList();
  for (auto reg : reg_array)
    temp_list->Append(RegManager::regs_[reg]);
  return temp_list;
}

temp::TempList *X64RegManager::ReturnSink() {
  temp::TempList *temp_list = CalleeSaves();
  temp_list->Append(RegManager::regs_[REG_RSP]);
  temp_list->Append(RegManager::regs_[REG_RAX]);
  return temp_list;
}

int X64RegManager::WordSize() { return 8; }

temp::Temp *X64RegManager::FramePointer() { return RegManager::regs_[REG_RBP]; }

temp::Temp *X64RegManager::StackPointer() { return RegManager::regs_[REG_RSP]; }

temp::Temp *X64RegManager::ReturnValue() { return RegManager::regs_[REG_RAX]; }

class InFrameAccess : public Access {
public:
  int offset;

  explicit InFrameAccess(int offset) : offset(offset) {}
  tree::Exp *ToExp(tree::Exp *frame_ptr) const override {
    return new tree::MemExp(new tree::BinopExp(tree::PLUS_OP, frame_ptr,
                                               new tree::ConstExp(offset)));
  }
};

class InRegAccess : public Access {
public:
  temp::Temp *reg;

  explicit InRegAccess(temp::Temp *reg) : reg(reg) {}
  tree::Exp *ToExp(tree::Exp *framePtr) const override {
    return new tree::TempExp(reg);
  }
};

class X64Frame : public Frame {
public:
  tree::Stm *view_shift;

  X64Frame(temp::Label *name, std::list<frame::Access *> *formals)
      : Frame(8, 0, name, formals), view_shift(nullptr) {}

  [[nodiscard]] std::string GetLabel() const override {
    return name_ ? name_->Name() : "";
  }
  [[nodiscard]] temp::Label *Name() const override { return name_; }
  [[nodiscard]] std::list<frame::Access *> *Formals() const override {
    return formals_;
  }
  frame::Access *AllocLocal(bool escape) override {
    frame::Access *access = nullptr;
    if (escape) {
      offset_ -= word_size_;
      access = new InFrameAccess(offset_);
    } else {
      access = new InRegAccess(temp::TempFactory::NewTemp());
    }
    return access;
  }
  void AllocOutgoSpace(int size) override {}
};

frame::Frame *NewFrame(temp::Label *name, std::list<bool> formals) {
  auto *access_list = new std::list<frame::Access *>();
  auto *frame = new X64Frame(name, access_list);

  temp::TempList *arg_regs = reg_manager->ArgRegs();
  auto arg_reg_it = arg_regs->GetList().begin();

  int incoming_stack_offset = 16;
  tree::Stm *shift_stm = nullptr;

  for (bool escape : formals) {
    frame::Access *access = nullptr;

    if (arg_reg_it != arg_regs->GetList().end()) {
      temp::Temp *actual_reg = *arg_reg_it++;
      access = frame->AllocLocal(escape);

      tree::Stm *move_formal = new tree::MoveStm(
          access->ToExp(new tree::TempExp(reg_manager->FramePointer())),
          new tree::TempExp(actual_reg)
      );

      if (!shift_stm) shift_stm = move_formal;
      else shift_stm = new tree::SeqStm(shift_stm, move_formal);
    } else {
      access = new InFrameAccess(incoming_stack_offset);
      incoming_stack_offset += 8;
    }

    access_list->push_back(access);
  }

  frame->view_shift = shift_stm;
  return frame;
}

tree::Exp *ExternalCall(std::string_view s, tree::ExpList *args) {
  return new tree::CallExp(new tree::NameExp(temp::LabelFactory::NamedLabel(std::string(s))),
                           args);
}

tree::Stm *ProcEntryExit1(frame::Frame *frame, tree::Stm *stm) {
  auto x64_frame = dynamic_cast<frame::X64Frame *>(frame);
  assert(x64_frame);

  auto callee_list = new tree::ExpList();

  tree::Stm *save_stm = nullptr;
  temp::TempList *callees = reg_manager->CalleeSaves();
  for (auto callee : callees->GetList()) {
    temp::Temp *r = temp::TempFactory::NewTemp();
    if (!save_stm)
      save_stm = new tree::MoveStm(new tree::TempExp(r), new tree::TempExp(callee));
    else
      save_stm = new tree::SeqStm(save_stm, new tree::MoveStm(new tree::TempExp(r), new tree::TempExp(callee)));
    callee_list->Append(new tree::TempExp(r));
  }

  tree::Stm *restore_stm = nullptr;
  callees = reg_manager->CalleeSaves();
  auto callee_it = callee_list->GetList().begin();
  for (auto callee : callees->GetList()) {
    assert(callee_it != callee_list->GetList().end());
    if (!restore_stm)
      restore_stm = new tree::MoveStm(new tree::TempExp(callee), *callee_it++);
    else
      restore_stm = new tree::SeqStm(restore_stm, new tree::MoveStm(new tree::TempExp(callee), *callee_it++));
  }

  tree::Stm *exit_stm;
  if (x64_frame->view_shift == nullptr) {
    exit_stm = new tree::SeqStm(save_stm, new tree::SeqStm(stm, restore_stm));
  } else
    exit_stm = new tree::SeqStm(save_stm, new tree::SeqStm(x64_frame->view_shift, new tree::SeqStm(stm, restore_stm)));
  return exit_stm;
}

assem::Proc *ProcEntryExit3(Frame *frame, assem::InstrList *body) {
  std::string prolog = frame->GetLabel() + ":\n";
  std::string epilog = "retq\n";

  return new assem::Proc(prolog, body, epilog);
}

} // namespace frame